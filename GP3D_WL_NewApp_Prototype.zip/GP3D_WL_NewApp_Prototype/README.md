# GP3D Field Meter — new Android prototype

Purpose:
- Connect to the existing GP-3D WL receiver over its local Wi-Fi.
- Use a completely new UI.
- Read actual receiver data from the reference endpoint.
- Show the raw response so protocol assumptions can be verified.
- Parse the same fields currently parsed by the reference APK.

## Reference APK finding
The supplied APK contains `GP-GL-3D-Long-Scan_Server.py` and uses:

`http://192.168.4.1/r_data`

It reads the response as UTF-8 and parses:
- `source1 = int(data[8:11])`
- `source2 = int(data[20:23])`
- mode = WATER when `tbhd` occurs, otherwise MINERAL.

## Important
This is a **communication prototype**, not yet a claim that every GP-3D WL survey calculation has been reproduced. The real transmitter/receiver must be tested to confirm the complete protocol and all fields.

## Build
Open this folder in Android Studio. Android applications are normally built with Gradle/Android Gradle Plugin. The APK can be generated from:
Build > Generate App Bundle(s) / APK(s) > Generate APK(s).

The app targets Android 35 and requests Internet/Wi-Fi permissions because it communicates with a local Wi-Fi device.
