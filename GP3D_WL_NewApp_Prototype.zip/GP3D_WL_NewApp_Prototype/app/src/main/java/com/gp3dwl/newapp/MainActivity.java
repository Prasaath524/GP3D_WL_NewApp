package com.gp3dwl.newapp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String DEVICE_URL = "http://192.168.4.1/r_data";
    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView status, raw, s1, s2, mode;
    private Button connectBtn, sampleBtn, stopBtn;
    private volatile boolean polling = false;
    private Network boundNetwork = null;

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            if (!polling) return;
            fetchReading();
            handler.postDelayed(this, 700);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, 7);
        }
    }

    private TextView tv(String text, float sp) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(sp); v.setTextColor(Color.WHITE);
        v.setPadding(18, 10, 18, 10);
        return v;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18);
        root.setBackgroundColor(Color.rgb(12, 20, 28));

        TextView title = tv("GP3D FIELD METER", 25);
        title.setTypeface(null, 1);
        root.addView(title);

        status = tv("● Disconnected", 15);
        status.setTextColor(Color.rgb(255, 180, 70));
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        connectBtn = new Button(this); connectBtn.setText("CONNECT");
        sampleBtn = new Button(this); sampleBtn.setText("SINGLE READING");
        stopBtn = new Button(this); stopBtn.setText("STOP");
        row.addView(connectBtn, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(sampleBtn, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(stopBtn, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        mode = tv("Mode: —", 16);
        root.addView(mode);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);

        s1 = tv("SOURCE 1\n—", 21);
        s2 = tv("SOURCE 2\n—", 21);
        s1.setGravity(Gravity.CENTER); s2.setGravity(Gravity.CENTER);
        s1.setBackgroundColor(Color.rgb(27, 55, 78));
        s2.setBackgroundColor(Color.rgb(33, 74, 59));

        cards.addView(s1, new LinearLayout.LayoutParams(0, 150, 1));
        cards.addView(s2, new LinearLayout.LayoutParams(0, 150, 1));
        root.addView(cards);

        TextView rawTitle = tv("RAW DEVICE RESPONSE", 14);
        rawTitle.setTypeface(null, 1);
        root.addView(rawTitle);

        raw = tv("No data yet", 13);
        raw.setTextIsSelectable(true);
        raw.setBackgroundColor(Color.rgb(25, 31, 37));
        root.addView(raw, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView note = tv("Device endpoint: " + DEVICE_URL +
                "\nThis prototype reads the actual receiver response. It does not invent measurements.", 12);
        root.addView(note);

        setContentView(root);

        connectBtn.setOnClickListener(v -> startPolling());
        sampleBtn.setOnClickListener(v -> fetchReading());
        stopBtn.setOnClickListener(v -> stopPolling());
    }

    private void startPolling() {
        polling = true;
        status.setText("● Connecting…");
        status.setTextColor(Color.YELLOW);
        handler.removeCallbacks(poller);
        handler.post(poller);
    }

    private void stopPolling() {
        polling = false;
        handler.removeCallbacks(poller);
        status.setText("● Stopped");
        status.setTextColor(Color.LTGRAY);
    }

    private void fetchReading() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(DEVICE_URL);
                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(1200);
                c.setReadTimeout(1200);
                c.setRequestMethod("GET");

                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();

                String data = sb.toString();
                Parsed p = parseReferenceFormat(data);

                runOnUiThread(() -> {
                    status.setText("● Receiver connected");
                    status.setTextColor(Color.rgb(70, 220, 120));
                    mode.setText("Mode: " + p.mode);
                    s1.setText(String.format(Locale.US, "SOURCE 1\n%d", p.source1));
                    s2.setText(String.format(Locale.US, "SOURCE 2\n%d", p.source2));
                    raw.setText(data);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("● No receiver response");
                    status.setTextColor(Color.rgb(255, 100, 90));
                    raw.setText("Connection error:\n" + e.getClass().getSimpleName() +
                            "\n" + String.valueOf(e.getMessage()));
                });
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    /*
     * Reference APK parser:
     * source1 = int(data[8:11])
     * source2 = int(data[20:23])
     * if "tbhd" occurs after index 0, mode = W else M.
     *
     * We keep this parser isolated so the exact receiver protocol can be
     * refined after testing against the user's real GP-3D WL receiver.
     */
    private Parsed parseReferenceFormat(String data) {
        int a = -1, b = -1;
        String m = data.contains("tbhd") ? "WATER" : "MINERAL";
        try {
            if (data.length() >= 23) {
                a = Integer.parseInt(data.substring(8, 11));
                b = Integer.parseInt(data.substring(20, 23));
            }
        } catch (Exception ignored) {}
        return new Parsed(a, b, m);
    }

    private static class Parsed {
        final int source1, source2; final String mode;
        Parsed(int a, int b, String m) { source1=a; source2=b; mode=m; }
    }

    @Override protected void onDestroy() {
        stopPolling();
        super.onDestroy();
    }
}
